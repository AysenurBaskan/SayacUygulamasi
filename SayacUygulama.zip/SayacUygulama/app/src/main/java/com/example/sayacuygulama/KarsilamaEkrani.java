package com.example.sayacuygulama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class KarsilamaEkrani extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_karsilama_ekrani);

        (new Handler()).postDelayed(new Runnable() {
            @Override
            public void run() {

                startActivity(new Intent(KarsilamaEkrani.this,MainActivity.class));

                }
            }, 2000);
        }

    }
