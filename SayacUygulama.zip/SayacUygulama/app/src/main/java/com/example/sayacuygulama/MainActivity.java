package com.example.sayacuygulama;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    int sayac=0;
    Button artirma;
    Button azaltma;
    TextView sayacid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sayacid = (TextView)findViewById(R.id.sayacid);
        artirma = (Button)findViewById(R.id.artirma);
        azaltma = (Button)findViewById(R.id.azaltma);

        azaltma.setOnClickListener(view ->{
            sayac--;
            sayacid.setText(String.valueOf(sayac));
        });

        artirma.setOnClickListener(view ->{
            sayac++;
            sayacid.setText(String.valueOf(sayac));
        });

    }
}